import smtplib

def prompt(prompt):
    return input(prompt).strip()

#fromaddr = prompt("From: ")
#toaddrs  = prompt("To: ").split()
#print("Enter message, end with ^D (Unix) or ^Z (Windows):")
apipass="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"
login="apikey"
# Add the From: and To: headers at the start!
#msg = ("From: %s\r\nTo: %s\r\nSubject: %s\r\n"
#       % (fromaddr, ", ".join(toaddrs)))
from email.message import EmailMessage
msg=""
msg1=EmailMessage()
msg1["From"]="support@imusti.com"
msg1["To"]="techiesarava@blaze.ws"
msg1["Subject"]="This is a test message from send grid (Azure)"
while True:
    try:
        line = input()
    except EOFError:
        break
    if not line:
        break
    msg = msg + line

msg1["Message"]=msg
print("Message length is", len(msg))

server = smtplib.SMTP('smtp.sendgrid.net',587)
server.set_debuglevel(1)
server.login(login,apipass)
server.sendmail("support@imusti.com", "techiesarava@gmail.com", msg)
server.quit()
