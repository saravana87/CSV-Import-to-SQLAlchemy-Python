import smtplib
server = smtplib.SMTP('smtp.sendgrid.net', 587)
from email.message import EmailMessage

#Next, log in to the server
#server.login("apikey","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")
apipass="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"
login="apikey"
message=""
smtpserver='smtp.sendgrid.net:587'
def sendemail(from_addr, to_addr_list, cc_addr_list,subject, message,login,password,smtpserver='smtp.sendgrid.net:587'):
    header  = 'From: %s' % from_addr
    header += 'To: %s' % ','.join(to_addr_list)
    header += 'Cc: %s' % ','.join(cc_addr_list)
    header += 'Subject: %s' % subject
    message = header + message
 

from_addr="support@imusti.com"
to_addr_list=['mskumar.87@gmail.com']
cc_addr_list=['techiesarava@gmail.com']
subject="The New One"
#message="hi how are you"
header  = 'From: <%s' % from_addr +'>'
header += 'To: %s' % ','.join(to_addr_list)
header += 'Cc: %s' % ','.join(cc_addr_list)
header += 'Subject: %s' % subject

message = header + message
from email.message import EmailMessage
message2=EmailMessage()
message2['Subject'] = "I am New One"
message2['From'] = "support@imusti.com"
message2['To'] = "techiesarava@gmail.com"

server = smtplib.SMTP(smtpserver)
server.starttls()
server.login(login,apipass)
#print(message)
problems = server.sendmail("support@imusti.com", "techiesarava@gmail.com", message2)
print(problems)
server.quit()


#sendemail("support@imusti.com","mskumar.87@gmail.com","","The new one","Hi How are you","apikey",apipass,'') 
